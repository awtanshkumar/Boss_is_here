package com.lti.dto;

public class ViewUserDetailsDto {
	private String firstName;
	private String middleName;
	private String lastName;
	private String mobileNumber;
	private String email;
	private String aadharCard;
	private String resAddress1;
	private String resAddress2;
	private String resLandMark;
	private String resState;
	private String resCity;
	private String resPincode;
	private int accountBalance;
	private String occupation = "Self-Employed";
	
	
	public int getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAadharCard() {
		return aadharCard;
	}
	public void setAadharCard(String aadharCard) {
		this.aadharCard = aadharCard;
	}
	public String getResAddress1() {
		return resAddress1;
	}
	public void setResAddress1(String resAddress1) {
		this.resAddress1 = resAddress1;
	}
	public String getResAddress2() {
		return resAddress2;
	}
	public void setResAddress2(String resAddress2) {
		this.resAddress2 = resAddress2;
	}
	public String getResLandMark() {
		return resLandMark;
	}
	public void setResLandMark(String resLandMark) {
		this.resLandMark = resLandMark;
	}
	public String getResState() {
		return resState;
	}
	public void setResState(String resState) {
		this.resState = resState;
	}
	public String getResCity() {
		return resCity;
	}
	public void setResCity(String resCity) {
		this.resCity = resCity;
	}
	public String getResPincode() {
		return resPincode;
	}
	public void setResPincode(String resPincode) {
		this.resPincode = resPincode;
	}
	
	
}