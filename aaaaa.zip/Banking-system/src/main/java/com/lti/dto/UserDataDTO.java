package com.lti.dto;

public class UserDataDTO {
	private String accNumber;
	private String lgnPassword;
	private String tnPassword;
	
	public String getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
	public String getLgnPassword() {
		return lgnPassword;
	}
	public void setLgnPassword(String lgnPassword) {
		this.lgnPassword = lgnPassword;
	}
	public String getTnPassword() {
		return tnPassword;
	}
	public void setTnPassword(String tnPassword) {
		this.tnPassword = tnPassword;
	}
	
}

