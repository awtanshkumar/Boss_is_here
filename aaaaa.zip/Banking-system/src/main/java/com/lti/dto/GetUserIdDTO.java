package com.lti.dto;

public class GetUserIdDTO {
	private String accNumber;

	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
}
